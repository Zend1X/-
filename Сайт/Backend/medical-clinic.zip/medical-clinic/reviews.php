<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

// Создаем таблицу отзывов, если она не существует
$create_table = "
CREATE TABLE IF NOT EXISTS reviews (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(200) NOT NULL,
    rating TINYINT UNSIGNED NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT NOT NULL,
    doctor_id INT UNSIGNED,
    is_approved TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB
";
$conn->exec($create_table);

$message = '';
$message_type = '';

// Обработка формы добавления отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_name = sanitize($_POST['patient_name']);
    $rating = (int)$_POST['rating'];
    $review_text = sanitize($_POST['review_text']);
    $doctor_id = !empty($_POST['doctor_id']) ? (int)$_POST['doctor_id'] : null;
    
    $errors = [];
    
    if (empty($patient_name)) {
        $errors[] = 'Введите ваше имя';
    }
    
    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Поставьте оценку';
    }
    
    if (empty($review_text)) {
        $errors[] = 'Напишите текст отзыва';
    }
    
    if (empty($errors)) {
        $query = "INSERT INTO reviews (patient_name, rating, review_text, doctor_id, is_approved) VALUES (?, ?, ?, ?, 0)";
        $stmt = $conn->prepare($query);
        
        if ($stmt->execute([$patient_name, $rating, $review_text, $doctor_id])) {
            $message = 'Спасибо за ваш отзыв! Он будет опубликован после проверки модератором.';
            $message_type = 'success';
        } else {
            $message = 'Произошла ошибка. Пожалуйста, попробуйте позже.';
            $message_type = 'error';
        }
    } else {
        $message = implode('<br>', $errors);
        $message_type = 'error';
    }
}

// Получаем одобренные отзывы
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 9;
$offset = ($page - 1) * $per_page;

$count_query = "SELECT COUNT(*) FROM reviews WHERE is_approved = 1";
$total = $conn->query($count_query)->fetchColumn();
$total_pages = ceil($total / $per_page);

$query = "SELECT r.*, d.last_name, d.first_name, d.middle_name, d.photo as doctor_photo,
          s.title as specialization_name
          FROM reviews r 
          LEFT JOIN doctors d ON r.doctor_id = d.id 
          LEFT JOIN specializations s ON d.specialization_id = s.id 
          WHERE r.is_approved = 1 
          ORDER BY r.created_at DESC 
          LIMIT $per_page OFFSET $offset";
$reviews = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Статистика отзывов
$stats_query = "SELECT 
    COUNT(*) as total_reviews,
    AVG(rating) as avg_rating,
    COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star,
    COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star,
    COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star,
    COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star,
    COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star
FROM reviews WHERE is_approved = 1";
$stats = $conn->query($stats_query)->fetch(PDO::FETCH_ASSOC);

// Врачи для формы
$doctors_query = "SELECT d.id, d.last_name, d.first_name, d.middle_name, s.title as specialization 
                 FROM doctors d 
                 JOIN specializations s ON d.specialization_id = s.id 
                 WHERE d.is_published = 1 
                 ORDER BY d.last_name";
$doctors = $conn->query($doctors_query)->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<!-- Хлебные крошки -->
<div class="breadcrumbs">
    <div class="container">
        <a href="/">Главная</a>
        <span>/</span>
        Отзывы
    </div>
</div>

<section class="section">
    <div class="container">
        <h1 class="section-title">Отзывы пациентов</h1>
        
        <!-- Статистика -->
        <?php if ($stats['total_reviews'] > 0): ?>
        <div style="background: white; padding: 40px; border-radius: var(--radius); box-shadow: var(--shadow); margin-bottom: 40px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; align-items: center;">
                <div style="text-align: center;">
                    <div style="font-size: 48px; font-weight: 700; color: var(--primary);">
                        <?php echo number_format($stats['avg_rating'], 1); ?>
                    </div>
                    <div style="color: #ffc107; font-size: 24px; margin: 10px 0;">
                        <?php 
                        $full_stars = floor($stats['avg_rating']);
                        $half_star = ($stats['avg_rating'] - $full_stars) >= 0.5;
                        for ($i = 0; $i < $full_stars; $i++) echo '⭐';
                        if ($half_star) echo '✨';
                        ?>
                    </div>
                    <div style="color: var(--gray);">
                        На основе <?php echo $stats['total_reviews']; ?> отзывов
                    </div>
                </div>
                
                <div>
                    <div style="margin-bottom: 10px;">
                        <span style="color: var(--dark);">⭐⭐⭐⭐⭐</span>
                        <span style="color: var(--gray); margin-left: 10px;"><?php echo $stats['five_star']; ?> отзывов</span>
                        <div style="background: #e0e0e0; height: 8px; border-radius: 4px; margin-top: 5px;">
                            <div style="background: #ffc107; height: 8px; border-radius: 4px; width: <?php echo ($stats['five_star'] / $stats['total_reviews']) * 100; ?>%;"></div>
                        </div>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <span style="color: var(--dark);">⭐⭐⭐⭐</span>
                        <span style="color: var(--gray); margin-left: 10px;"><?php echo $stats['four_star']; ?> отзывов</span>
                        <div style="background: #e0e0e0; height: 8px; border-radius: 4px; margin-top: 5px;">
                            <div style="background: #ffc107; height: 8px; border-radius: 4px; width: <?php echo ($stats['four_star'] / $stats['total_reviews']) * 100; ?>%;"></div>
                        </div>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <span style="color: var(--dark);">⭐⭐⭐</span>
                        <span style="color: var(--gray); margin-left: 10px;"><?php echo $stats['three_star']; ?> отзывов</span>
                        <div style="background: #e0e0e0; height: 8px; border-radius: 4px; margin-top: 5px;">
                            <div style="background: #ffc107; height: 8px; border-radius: 4px; width: <?php echo ($stats['three_star'] / $stats['total_reviews']) * 100; ?>%;"></div>
                        </div>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <span style="color: var(--dark);">⭐⭐</span>
                        <span style="color: var(--gray); margin-left: 10px;"><?php echo $stats['two_star']; ?> отзывов</span>
                        <div style="background: #e0e0e0; height: 8px; border-radius: 4px; margin-top: 5px;">
                            <div style="background: #ffc107; height: 8px; border-radius: 4px; width: <?php echo ($stats['two_star'] / $stats['total_reviews']) * 100; ?>%;"></div>
                        </div>
                    </div>
                    <div>
                        <span style="color: var(--dark);">⭐</span>
                        <span style="color: var(--gray); margin-left: 10px;"><?php echo $stats['one_star']; ?> отзывов</span>
                        <div style="background: #e0e0e0; height: 8px; border-radius: 4px; margin-top: 5px;">
                            <div style="background: #ffc107; height: 8px; border-radius: 4px; width: <?php echo ($stats['one_star'] / $stats['total_reviews']) * 100; ?>%;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Кнопка добавления отзыва -->
        <div style="text-align: center; margin-bottom: 40px;">
            <button onclick="document.getElementById('reviewForm').scrollIntoView({behavior: 'smooth'});" class="btn btn-primary">
                ✍️ Оставить отзыв
            </button>
        </div>
        
        <!-- Список отзывов -->
        <?php if (count($reviews) > 0): ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px; margin-bottom: 40px;">
            <?php foreach ($reviews as $review): ?>
            <div style="background: white; padding: 30px; border-radius: var(--radius); box-shadow: var(--shadow);">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="width: 50px; height: 50px; border-radius: 50%; background: var(--light); display: flex; align-items: center; justify-content: center; font-size: 24px; color: var(--primary);">
                            👤
                        </div>
                        <div>
                            <div style="font-weight: 600; color: var(--dark);">
                                <?php echo htmlspecialchars($review['patient_name']); ?>
                            </div>
                            <div style="font-size: 14px; color: var(--gray);">
                                <?php echo formatDate($review['created_at']); ?>
                            </div>
                        </div>
                    </div>
                    <div style="color: #ffc107; font-size: 18px;">
                        <?php echo str_repeat('⭐', $review['rating']); ?>
                    </div>
                </div>
                
                <?php if ($review['last_name']): ?>
                <div style="margin-bottom: 15px; padding: 10px; background: var(--light); border-radius: 5px; font-size: 14px;">
                    <strong>Врач:</strong> 
                    <?php echo htmlspecialchars($review['last_name'] . ' ' . $review['first_name'] . ' ' . $review['middle_name']); ?>
                    <?php if ($review['specialization_name']): ?>
                    <span style="color: var(--gray);"> - <?php echo htmlspecialchars($review['specialization_name']); ?></span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <p style="color: #555; line-height: 1.8;">
                    <?php echo nl2br(htmlspecialchars($review['review_text'])); ?>
                </p>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Пагинация -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>" class="<?php echo $page == $i ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        
        <?php else: ?>
        <div style="text-align: center; padding: 40px; background: white; border-radius: var(--radius); box-shadow: var(--shadow);">
            <div style="font-size: 64px; margin-bottom: 20px;">💬</div>
            <h3 style="color: var(--dark); margin-bottom: 10px;">Отзывов пока нет</h3>
            <p style="color: var(--gray);">Будьте первым, кто оставит отзыв о нашей работе!</p>
        </div>
        <?php endif; ?>
        
        <!-- Форма добавления отзыва -->
        <div id="reviewForm" style="max-width: 600px; margin: 60px auto 0; background: white; padding: 40px; border-radius: var(--radius); box-shadow: var(--shadow);">
            <h2 style="margin-bottom: 25px; text-align: center; color: var(--dark);">Оставить отзыв</h2>
            
            <?php if ($message): ?>
            <div class="<?php echo $message_type === 'success' ? 'success-message' : 'error-message'; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label class="form-label" for="patient_name">Ваше имя *</label>
                    <input type="text" id="patient_name" name="patient_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Оценка *</label>
                    <div style="display: flex; gap: 10px; font-size: 30px;" id="ratingStars">
                        <span data-rating="1" style="cursor: pointer; opacity: 0.3;" onclick="setRating(1)">⭐</span>
                        <span data-rating="2" style="cursor: pointer; opacity: 0.3;" onclick="setRating(2)">⭐</span>
                        <span data-rating="3" style="cursor: pointer; opacity: 0.3;" onclick="setRating(3)">⭐</span>
                        <span data-rating="4" style="cursor: pointer; opacity: 0.3;" onclick="setRating(4)">⭐</span>
                        <span data-rating="5" style="cursor: pointer; opacity: 0.3;" onclick="setRating(5)">⭐</span>
                    </div>
                    <input type="hidden" name="rating" id="ratingInput" value="0" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="doctor_id">Врач (если хотите отметить конкретного специалиста)</label>
                    <select id="doctor_id" name="doctor_id" class="form-select">
                        <option value="">Выберите врача</option>
                        <?php foreach ($doctors as $doctor): ?>
                        <option value="<?php echo $doctor['id']; ?>">
                            <?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name'] . ' - ' . $doctor['specialization']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="review_text">Ваш отзыв *</label>
                    <textarea id="review_text" name="review_text" class="form-textarea" placeholder="Поделитесь вашим опытом посещения нашей клиники" required></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Отправить отзыв
                </button>
            </form>
        </div>
    </div>
</section>

<script>
function setRating(rating) {
    document.getElementById('ratingInput').value = rating;
    const stars = document.querySelectorAll('#ratingStars span');
    stars.forEach(star => {
        const starRating = parseInt(star.dataset.rating);
        if (starRating <= rating) {
            star.style.opacity = '1';
        } else {
            star.style.opacity = '0.3';
        }
    });
}

// Добавляем hover эффект
document.querySelectorAll('#ratingStars span').forEach(star => {
    star.addEventListener('mouseenter', function() {
        const rating = parseInt(this.dataset.rating);
        const stars = document.querySelectorAll('#ratingStars span');
        stars.forEach(s => {
            if (parseInt(s.dataset.rating) <= rating) {
                s.style.opacity = '1';
                s.style.transform = 'scale(1.2)';
            }
        });
    });
    
    star.addEventListener('mouseleave', function() {
        const currentRating = parseInt(document.getElementById('ratingInput').value);
        const stars = document.querySelectorAll('#ratingStars span');
        stars.forEach(s => {
            s.style.transform = 'scale(1)';
            if (parseInt(s.dataset.rating) <= currentRating) {
                s.style.opacity = '1';
            } else {
                s.style.opacity = '0.3';
            }
        });
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>