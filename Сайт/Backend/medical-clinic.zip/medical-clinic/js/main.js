// Мобильное меню
function toggleMenu() {
    const nav = document.getElementById('mainNav');
    nav.classList.toggle('active');
}

// Закрытие меню при клике на ссылку
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            const nav = document.getElementById('mainNav');
            if (nav.classList.contains('active')) {
                nav.classList.remove('active');
            }
        });
    });
    
    // Валидация формы записи
    const appointmentForm = document.getElementById('appointmentForm');
    if (appointmentForm) {
        appointmentForm.addEventListener('submit', function(e) {
            let isValid = true;
            const errors = [];
            
            const name = document.getElementById('patient_name');
            const phone = document.getElementById('phone');
            
            if (name && !name.value.trim()) {
                errors.push('Введите ваше имя');
                name.style.borderColor = '#e53935';
                isValid = false;
            } else if (name) {
                name.style.borderColor = '#e0e0e0';
            }
            
            if (phone) {
                const phoneRegex = /^\+?[0-9]{10,15}$/;
                if (!phoneRegex.test(phone.value.replace(/[\s-]/g, ''))) {
                    errors.push('Введите корректный номер телефона');
                    phone.style.borderColor = '#e53935';
                    isValid = false;
                } else {
                    phone.style.borderColor = '#e0e0e0';
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                const errorDiv = document.getElementById('formErrors');
                if (errorDiv) {
                    errorDiv.innerHTML = errors.map(e => `<p>${e}</p>`).join('');
                    errorDiv.style.display = 'block';
                }
            }
        });
    }
});

// Плавная прокрутка к якорям
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

console.log('Сайт медицинского центра загружен');