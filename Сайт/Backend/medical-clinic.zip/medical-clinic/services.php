<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

// Получаем категории с услугами
$categories_query = "SELECT * FROM service_categories WHERE is_active = 1 ORDER BY sort_order";
$categories_stmt = $conn->prepare($categories_query);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<!-- Хлебные крошки -->
<div class="breadcrumbs">
    <div class="container">
        <a href="<?php echo BASE_PATH; ?>/">Главная</a>
        <span>/</span>
        Услуги
    </div>
</div>

<section class="section">
    <div class="container">
        <h1 class="section-title">Наши услуги</h1>
        
        <?php if (count($categories) > 0): ?>
            <?php foreach ($categories as $category): ?>
                <?php
                $services_query = "SELECT * FROM services WHERE category_id = ? AND is_published = 1";
                $services_stmt = $conn->prepare($services_query);
                $services_stmt->execute([$category['id']]);
                $services = $services_stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($services) > 0):
                ?>
                <div style="margin-bottom: 60px;">
                    <h2 style="margin-bottom: 30px; color: #263238; font-size: 28px;">
                        <?php echo htmlspecialchars($category['title']); ?>
                    </h2>
                    <?php if ($category['description']): ?>
                    <p style="color: #78909c; margin-bottom: 30px; font-size: 16px;">
                        <?php echo htmlspecialchars($category['description']); ?>
                    </p>
                    <?php endif; ?>
                    
                    <div class="services-grid">
                        <?php foreach ($services as $service): ?>
                        <div class="service-card">
                            <div class="service-content">
                                <h3 class="service-title"><?php echo htmlspecialchars($service['title']); ?></h3>
                                <p class="service-desc"><?php echo htmlspecialchars($service['short_desc']); ?></p>
                                
                                <?php if ($service['full_desc']): ?>
                                <div style="color: #78909c; font-size: 14px; margin-bottom: 15px; line-height: 1.6;">
                                    <?php echo mb_substr(strip_tags($service['full_desc']), 0, 150) . '...'; ?>
                                </div>
                                <?php endif; ?>
                                
                                <div class="service-footer">
                                    <span class="service-price">
                                        <?php echo number_format($service['price'], 0, '.', ' '); ?> ₽
                                    </span>
                                    <span class="service-duration">
                                        ⏱ <?php echo $service['duration']; ?> мин.
                                    </span>
                                </div>
                                
                                <!-- ВАЖНО: Правильная ссылка на запись -->
                                <a href="<?php echo BASE_PATH; ?>/appointment.php?service_id=<?php echo $service['id']; ?>" 
                                   class="btn btn-primary" 
                                   style="margin-top: 15px; width: 100%; text-align: center;">
                                    Записаться на приём
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 60px 20px; background: white; border-radius: 10px;">
                <div style="font-size: 64px; margin-bottom: 20px;">💉</div>
                <h3 style="color: #263238; margin-bottom: 10px;">Услуг пока нет</h3>
                <p style="color: #78909c;">Информация об услугах скоро появится на сайте.</p>
            </div>
        <?php endif; ?>
        
        <!-- Блок призыва к действию -->
        <div style="text-align: center; margin-top: 60px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 50px; border-radius: 10px; color: white;">
            <h2 style="font-size: 32px; margin-bottom: 20px;">Не нашли нужную услугу?</h2>
            <p style="font-size: 18px; margin-bottom: 30px; opacity: 0.9;">Свяжитесь с нами, и мы подберем оптимальное решение для вас</p>
            <a href="<?php echo BASE_PATH; ?>/appointment.php" class="btn btn-primary" style="background: white; color: #667eea; font-size: 18px; padding: 15px 40px;">
                Записаться на приём
            </a>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>