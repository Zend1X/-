<?php
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';
include __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container" style="text-align: center;">
        <div style="font-size: 120px; color: var(--primary); margin-bottom: 20px;">404</div>
        <h1 style="font-size: 36px; margin-bottom: 20px;">Страница не найдена</h1>
        <p style="color: var(--gray); margin-bottom: 30px;">К сожалению, запрашиваемая страница не существует или была перемещена.</p>
        <a href="<?php echo BASE_PATH; ?>/" class="btn btn-primary">Вернуться на главную</a>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>