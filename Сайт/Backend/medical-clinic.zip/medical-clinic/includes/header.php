<?php
require_once __DIR__ . '/../config/paths.php';
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Медицинский центр "Здоровье"</title>
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>/css/style.css">
</head>
<body>
    <header class="header">
        <div class="header-top">
            <div class="container">
                <div class="header-contact">
                    <span>📞 +7 (999) 123-45-67</span>
                    <span>✉️ info@medcenter.ru</span>
                </div>
                <div>
                    🕐 Пн-Пт: 8:00-20:00 | Сб: 9:00-18:00
                </div>
            </div>
        </div>
        <div class="header-main">
            <div class="container">
                <a href="<?php echo BASE_PATH; ?>/" class="logo">Мед<span>Центр</span></a>
                <button class="mobile-menu-btn" onclick="toggleMenu()">☰</button>
                <ul class="nav" id="mainNav">
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/" class="nav-link <?php echo ($current_page == 'index.php' || $current_page == '') ? 'active' : ''; ?>">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/services.php" class="nav-link <?php echo $current_page == 'services.php' ? 'active' : ''; ?>">Услуги</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/doctors.php" class="nav-link <?php echo $current_page == 'doctors.php' || $current_page == 'doctor.php' ? 'active' : ''; ?>">Врачи</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/reviews.php" class="nav-link <?php echo $current_page == 'reviews.php' ? 'active' : ''; ?>">Отзывы</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/news.php" class="nav-link <?php echo $current_page == 'news.php' ? 'active' : ''; ?>">Новости</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/contacts.php" class="nav-link <?php echo $current_page == 'contacts.php' ? 'active' : ''; ?>">Контакты</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo BASE_PATH; ?>/appointment.php" class="btn btn-primary">Записаться</a>
                    </li>
                </ul>
            </div>
        </div>
    </header>