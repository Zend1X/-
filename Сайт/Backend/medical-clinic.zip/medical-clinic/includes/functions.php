<?php
// Запускаем сессию только если она еще не запущена
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/paths.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1;
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function site_url($path = '') {
    return BASE_PATH . '/' . ltrim($path, '/');
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function validatePhone($phone) {
    $phone = preg_replace('/[\s\-\(\)]/', '', $phone);
    return preg_match('/^\+?[0-9]{10,15}$/', $phone);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function getStatusBadge($status) {
    $badges = [
        'new' => '<span class="badge badge-new">Новая</span>',
        'processing' => '<span class="badge badge-processing">В обработке</span>',
        'confirmed' => '<span class="badge badge-confirmed">Подтверждена</span>',
        'rejected' => '<span class="badge badge-rejected">Отклонена</span>',
        'completed' => '<span class="badge badge-completed">Завершена</span>',
        'answered' => '<span class="badge badge-answered">Отвечено</span>',
        'closed' => '<span class="badge badge-closed">Закрыто</span>'
    ];
    return $badges[$status] ?? '';
}

function formatDate($date) {
    if (empty($date)) return '';
    return date('d.m.Y H:i', strtotime($date));
}

function formatDateOnly($date) {
    if (empty($date)) return '';
    return date('d.m.Y', strtotime($date));
}
?>