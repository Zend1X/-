    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div>
                    <h3 class="footer-title">МедЦентр</h3>
                    <p>Современная медицина с заботой о каждом пациенте. Мы используем передовые технологии и индивидуальный подход.</p>
                </div>
                <div>
                    <h3 class="footer-title">Навигация</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_PATH; ?>/">Главная</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/services.php">Все услуги</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/doctors.php">Наши врачи</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/reviews.php">Отзывы пациентов</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/news.php">Новости</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/appointment.php">Запись на приём</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="footer-title">Контакты</h3>
                    <ul class="footer-links">
                        <li><a href="tel:+79991234567">📞 +7 (999) 123-45-67</a></li>
                        <li><a href="mailto:info@medcenter.ru">✉️ info@medcenter.ru</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/contacts.php">📍 г. Москва, ул. Медицинская, 15</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="footer-title">О центре</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_PATH; ?>/contacts.php">Контакты</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/reviews.php">Отзывы</a></li>
                        <li><a href="<?php echo BASE_PATH; ?>/appointment.php">Записаться</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Медицинский центр "Здоровье". Все права защищены.</p>
            </div>
        </div>
    </footer>
    
    <script src="<?php echo BASE_PATH; ?>/js/main.js"></script>
</body>
</html> 