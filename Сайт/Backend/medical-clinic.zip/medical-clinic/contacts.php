<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$message = '';
$message_type = '';

// Обработка формы обратной связи
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $message_text = sanitize($_POST['message']);
    
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Введите ваше имя';
    }
    
    if (empty($email) || !validateEmail($email)) {
        $errors[] = 'Введите корректный email';
    }
    
    if (empty($message_text)) {
        $errors[] = 'Введите текст сообщения';
    }
    
    if (empty($errors)) {
        $db = new Database();
        $conn = $db->getConnection();
        
        $query = "INSERT INTO feedback (name, phone, email, subject, message, status_id) VALUES (?, ?, ?, ?, ?, 1)";
        $stmt = $conn->prepare($query);
        
        if ($stmt->execute([$name, $phone, $email, $subject, $message_text])) {
            $message = 'Ваше сообщение успешно отправлено! Мы ответим вам в ближайшее время.';
            $message_type = 'success';
        } else {
            $message = 'Произошла ошибка при отправке сообщения. Пожалуйста, попробуйте позже.';
            $message_type = 'error';
        }
    } else {
        $message = implode('<br>', $errors);
        $message_type = 'error';
    }
}

include __DIR__ . '/includes/header.php';
?>

<!-- Хлебные крошки -->
<div class="breadcrumbs">
    <div class="container">
        <a href="/">Главная</a>
        <span>/</span>
        Контакты
    </div>
</div>

<section class="section">
    <div class="container">
        <h1 class="section-title">Контакты</h1>
        
        <div class="contacts-grid">
            <!-- Контактная информация -->
            <div class="contact-info">
                <div class="contact-item">
                    <div class="contact-icon">📍</div>
                    <div class="contact-text">
                        <h4>Адрес</h4>
                        <p>г. Москва, ул. Медицинская, д. 15</p>
                        <p>Ближайшее метро: Медведково</p>
                    </div>
                </div>
                
                <div class="contact-item">
                    <div class="contact-icon">📞</div>
                    <div class="contact-text">
                        <h4>Телефоны</h4>
                        <p>+7 (999) 123-45-67</p>
                        <p>+7 (999) 765-43-21</p>
                    </div>
                </div>
                
                <div class="contact-item">
                    <div class="contact-icon">✉️</div>
                    <div class="contact-text">
                        <h4>Email</h4>
                        <p>info@medcenter.ru</p>
                        <p>appointment@medcenter.ru</p>
                    </div>
                </div>
                
                <div class="contact-item">
                    <div class="contact-icon">🕐</div>
                    <div class="contact-text">
                        <h4>Режим работы</h4>
                        <p>Понедельник - Пятница: 8:00 - 20:00</p>
                        <p>Суббота: 9:00 - 18:00</p>
                        <p>Воскресенье: выходной</p>
                    </div>
                </div>
                
                <div class="contact-item">
                    <div class="contact-icon">🚗</div>
                    <div class="contact-text">
                        <h4>Парковка</h4>
                        <p>Бесплатная парковка для пациентов на территории центра</p>
                    </div>
                </div>
            </div>
            
            <!-- Форма обратной связи -->
            <div>
                <div class="contact-form">
                    <h2 style="margin-bottom: 25px; color: var(--dark);">Остались вопросы?</h2>
                    <p style="margin-bottom: 25px; color: var(--gray);">Оставьте сообщение, и мы свяжемся с вами в ближайшее время</p>
                    
                    <?php if ($message): ?>
                    <div class="<?php echo $message_type === 'success' ? 'success-message' : 'error-message'; ?>">
                        <?php echo $message; ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="POST" id="feedbackForm">
                        <div class="form-group">
                            <label class="form-label" for="name">Ваше имя *</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="phone">Телефон</label>
                            <input type="tel" id="phone" name="phone" class="form-control" placeholder="+7 (999) 123-45-67">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="email">Email *</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="subject">Тема</label>
                            <select id="subject" name="subject" class="form-select">
                                <option value="">Выберите тему</option>
                                <option value="Запись на приём">Запись на приём</option>
                                <option value="Вопрос по услугам">Вопрос по услугам</option>
                                <option value="Предложение">Предложение</option>
                                <option value="Жалоба">Жалоба</option>
                                <option value="Сотрудничество">Сотрудничество</option>
                                <option value="Другое">Другое</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="message">Сообщение *</label>
                            <textarea id="message" name="message" class="form-textarea" placeholder="Опишите ваш вопрос или предложение" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            Отправить сообщение
                        </button>
                        
                        <p style="text-align: center; margin-top: 20px; color: var(--gray); font-size: 14px;">
                            * Обязательные поля для заполнения
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Карта -->
<section class="section-light">
    <div class="container">
        <h2 class="section-title">Как нас найти</h2>
        <div style="border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow);">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2242.1234567890!2d37.123456!3d55.123456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTXCsDA3JzI0LjQiTiAzN8KwMDcnMjQuNCJF!5e0!3m2!1sru!2sru!4v1234567890" 
                    width="100%" 
                    height="450" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy">
            </iframe>
        </div>
        
        <div style="margin-top: 40px; background: white; padding: 30px; border-radius: var(--radius); box-shadow: var(--shadow);">
            <h3 style="margin-bottom: 20px; color: var(--dark);">Как добраться</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <div>
                    <h4 style="color: var(--primary); margin-bottom: 10px;">🚇 На метро</h4>
                    <p style="color: #666;">Станция "Медведково", выход №3. Далее 5 минут пешком по улице Медицинской.</p>
                </div>
                <div>
                    <h4 style="color: var(--primary); margin-bottom: 10px;">🚗 На автомобиле</h4>
                    <p style="color: #666;">Съезд с МКАД на 91 км, далее по указателям. Бесплатная парковка на 50 машиномест.</p>
                </div>
                <div>
                    <h4 style="color: var(--primary); margin-bottom: 10px;">🚌 На автобусе</h4>
                    <p style="color: #666;">Автобусы №15, 27, 93 до остановки "Медицинский центр".</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>