<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

// Получаем популярные услуги
$services_query = "SELECT s.*, sc.title as category_name 
                  FROM services s 
                  JOIN service_categories sc ON s.category_id = sc.id 
                  WHERE s.is_published = 1 
                  LIMIT 6";
$services_stmt = $conn->prepare($services_query);
$services_stmt->execute();
$services = $services_stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем врачей
$doctors_query = "SELECT d.*, s.title as specialization_name 
                 FROM doctors d 
                 JOIN specializations s ON d.specialization_id = s.id 
                 WHERE d.is_published = 1 
                 LIMIT 4";
$doctors_stmt = $conn->prepare($doctors_query);
$doctors_stmt->execute();
$doctors = $doctors_stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем новости
$news_query = "SELECT n.*, u.login as author_name 
              FROM news n 
              LEFT JOIN users u ON n.author_id = u.id 
              WHERE n.is_visible = 1 
              ORDER BY n.published_at DESC 
              LIMIT 3";
$news_stmt = $conn->prepare($news_query);
$news_stmt->execute();
$news = $news_stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1>Забота о вашем здоровье</h1>
        <p>Профессиональная медицинская помощь с использованием современного оборудования и индивидуального подхода</p>
        <a href="<?php echo BASE_PATH; ?>/appointment.php" class="btn btn-primary">Записаться на приём</a>
    </div>
</section>

<!-- Features -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Почему выбирают нас</h2>
        <div class="features">
            <div class="feature-card">
                <div class="feature-icon">👨‍⚕️</div>
                <h3 class="feature-title">Опытные врачи</h3>
                <p>Специалисты с многолетним стажем и высокой квалификацией</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🔬</div>
                <h3 class="feature-title">Современное оборудование</h3>
                <p>Используем передовые технологии диагностики и лечения</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">❤️</div>
                <h3 class="feature-title">Индивидуальный подход</h3>
                <p>Внимательное отношение к каждому пациенту</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">⏰</div>
                <h3 class="feature-title">Удобный график</h3>
                <p>Работаем без выходных, запись онлайн в любое время</p>
            </div>
        </div>
    </div>
</section>

<!-- Services -->
<section class="section" style="background: #f5f7fa;">
    <div class="container">
        <h2 class="section-title">Наши услуги</h2>
        <div class="services-grid">
            <?php foreach ($services as $service): ?>
            <div class="service-card">
                <div class="service-content">
                    <h3 class="service-title"><?php echo htmlspecialchars($service['title']); ?></h3>
                    <p class="service-desc"><?php echo htmlspecialchars($service['short_desc']); ?></p>
                    <div class="service-footer">
                        <span class="service-price"><?php echo number_format($service['price'], 0, '.', ' '); ?> ₽</span>
                        <span class="service-duration">⏱ <?php echo $service['duration']; ?> мин.</span>
                    </div>
                    <a href="<?php echo BASE_PATH; ?>/appointment.php?service_id=<?php echo $service['id']; ?>" class="btn btn-primary" style="margin-top: 15px; width: 100%;">Записаться</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="text-align: center; margin-top: 40px;">
            <a href="<?php echo BASE_PATH; ?>/services.php" class="btn btn-outline">Все услуги</a>
        </div>
    </div>
</section>

<!-- Doctors -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Наши специалисты</h2>
        <div class="doctors-grid">
            <?php foreach ($doctors as $doctor): ?>
            <div class="doctor-card">
                <img src="<?php echo BASE_PATH . '/' . ($doctor['photo'] ?: 'images/default-doctor.jpg'); ?>" 
                     alt="<?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name']); ?>"
                     class="doctor-photo">
                <h3 class="doctor-name"><?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name']); ?></h3>
                <p class="doctor-specialty"><?php echo htmlspecialchars($doctor['specialization_name']); ?></p>
                <p class="doctor-experience">Стаж: <?php echo $doctor['experience']; ?> лет</p>
                <a href="<?php echo BASE_PATH; ?>/doctor.php?id=<?php echo $doctor['id']; ?>" class="btn btn-outline">Подробнее</a>
                <a href="<?php echo BASE_PATH; ?>/appointment.php?doctor_id=<?php echo $doctor['id']; ?>" class="btn btn-primary">Записаться</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- News -->
<section class="section" style="background: #f5f7fa;">
    <div class="container">
        <h2 class="section-title">Новости и статьи</h2>
        <div class="news-grid">
            <?php foreach ($news as $item): ?>
            <div class="news-card">
                <?php if ($item['image']): ?>
                <img src="<?php echo BASE_PATH . '/' . $item['image']; ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" class="news-image">
                <?php endif; ?>
                <div class="news-content">
                    <p class="news-date"><?php echo formatDate($item['published_at']); ?></p>
                    <h3 class="news-title"><?php echo htmlspecialchars($item['title']); ?></h3>
                    <p class="news-announce"><?php echo htmlspecialchars($item['announce']); ?></p>
                    <a href="<?php echo BASE_PATH; ?>/news.php?id=<?php echo $item['id']; ?>" class="btn btn-outline">Читать далее</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="hero" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
    <div class="container">
        <h1>Запишитесь на приём прямо сейчас</h1>
        <p>Оставьте заявку, и мы подберем удобное время для визита</p>
        <a href="<?php echo BASE_PATH; ?>/appointment.php" class="btn btn-primary" style="background: white; color: #667eea; font-size: 18px; padding: 15px 40px;">Записаться</a>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>