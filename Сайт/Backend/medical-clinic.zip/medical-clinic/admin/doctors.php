<?php
require_once __DIR__ . '/../config/database.php';
include __DIR__ . '/header.php';

$db = new Database();
$conn = $db->getConnection();

$message = '';
$message_type = '';

// CRUD операции
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $last_name = trim($_POST['last_name']);
        $first_name = trim($_POST['first_name']);
        $middle_name = trim($_POST['middle_name']);
        $specialization_id = (int)$_POST['specialization_id'];
        $experience = (int)$_POST['experience'];
        $bio = $_POST['bio'];
        $is_published = isset($_POST['is_published']) ? 1 : 0;
        
        $photo_path = $_POST['existing_photo'] ?? null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/../images/doctors/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $file_name = 'doctor_' . time() . '_' . uniqid() . '.' . $ext;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_dir . $file_name)) {
                if (!empty($_POST['existing_photo']) && file_exists(__DIR__ . '/../' . $_POST['existing_photo'])) {
                    unlink(__DIR__ . '/../' . $_POST['existing_photo']);
                }
                $photo_path = 'images/doctors/' . $file_name;
            }
        }
        
        if ($_POST['action'] === 'add') {
            $stmt = $conn->prepare("INSERT INTO doctors (last_name, first_name, middle_name, specialization_id, experience, bio, photo, is_published) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$last_name, $first_name, $middle_name, $specialization_id, $experience, $bio, $photo_path, $is_published]);
            $message = 'Врач добавлен';
            $message_type = 'success';
        } elseif ($_POST['action'] === 'edit') {
            $id = (int)$_POST['id'];
            $stmt = $conn->prepare("UPDATE doctors SET last_name=?, first_name=?, middle_name=?, specialization_id=?, experience=?, bio=?, photo=?, is_published=? WHERE id=?");
            $stmt->execute([$last_name, $first_name, $middle_name, $specialization_id, $experience, $bio, $photo_path, $is_published, $id]);
            $message = 'Данные обновлены';
            $message_type = 'success';
        }
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $stmt = $conn->prepare("SELECT photo FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        $doc = $stmt->fetch();
        if ($doc['photo'] && file_exists(__DIR__ . '/../' . $doc['photo'])) {
            unlink(__DIR__ . '/../' . $doc['photo']);
        }
        $conn->prepare("DELETE FROM doctors WHERE id = ?")->execute([$id]);
        $message = 'Врач удалён';
        $message_type = 'success';
    }
}

// Фильтры
$where = [];
$params = [];

if (!empty($_GET['spec'])) {
    $where[] = "d.specialization_id = ?";
    $params[] = (int)$_GET['spec'];
}

if (!empty($_GET['search'])) {
    $where[] = "(d.last_name LIKE ? OR d.first_name LIKE ? OR d.middle_name LIKE ?)";
    $search = "%{$_GET['search']}%";
    $params[] = $search; $params[] = $search; $params[] = $search;
}

if (isset($_GET['published']) && $_GET['published'] !== '') {
    $where[] = "d.is_published = ?";
    $params[] = (int)$_GET['published'];
}

$where_clause = count($where) ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT d.*, s.title as spec_name FROM doctors d JOIN specializations s ON d.specialization_id = s.id $where_clause ORDER BY d.last_name";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);

$specializations = $conn->query("SELECT * FROM specializations WHERE is_active = 1")->fetchAll();
?>

<div class="admin-content">
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h3>Врачи (<?php echo count($doctors); ?>)</h3>
            <button onclick="openModal()" class="btn btn-primary">+ Добавить врача</button>
        </div>
        <div class="card-body">
            <!-- Фильтры -->
            <form method="GET" class="search-box">
                <input type="text" name="search" placeholder="🔍 Поиск по ФИО..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="flex: 2;">
                <select name="spec" class="form-select" style="width: 180px;">
                    <option value="">Все специализации</option>
                    <?php foreach ($specializations as $spec): ?>
                    <option value="<?php echo $spec['id']; ?>" <?php echo ($_GET['spec'] ?? '') == $spec['id'] ? 'selected' : ''; ?>>
                        <?php echo $spec['title']; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <select name="published" class="form-select" style="width: 150px;">
                    <option value="">Все</option>
                    <option value="1" <?php echo ($_GET['published'] ?? '') === '1' ? 'selected' : ''; ?>>Опубликованные</option>
                    <option value="0" <?php echo ($_GET['published'] ?? '') === '0' ? 'selected' : ''; ?>>Скрытые</option>
                </select>
                <button type="submit" class="btn btn-primary">🔍</button>
                <?php if (!empty($_GET)): ?>
                <a href="doctors.php" class="btn btn-outline">✖</a>
                <?php endif; ?>
            </form>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Фото</th>
                            <th>ФИО</th>
                            <th>Специализация</th>
                            <th>Стаж</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($doctors as $doctor): ?>
                        <tr>
                            <td>
                                <?php if ($doctor['photo']): ?>
                                <img src="../<?php echo $doctor['photo']; ?>" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                                <?php else: ?>
                                <div style="width: 40px; height: 40px; border-radius: 50%; background: #e0e0e0; text-align: center; line-height: 40px;">👤</div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['spec_name']); ?></td>
                            <td><?php echo $doctor['experience']; ?> лет</td>
                            <td>
                                <span class="badge <?php echo $doctor['is_published'] ? 'badge-confirmed' : 'badge-rejected'; ?>">
                                    <?php echo $doctor['is_published'] ? 'Опубликован' : 'Скрыт'; ?>
                                </span>
                            </td>
                            <td>
                                <button onclick='editDoctor(<?php echo json_encode($doctor); ?>)' class="btn btn-info btn-sm">✏️</button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="id" value="<?php echo $doctor['id']; ?>">
                                    <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Удалить?')">🗑️</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно (без изменений) -->
<div class="modal-overlay" id="doctorModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modalTitle">Добавить врача</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <input type="hidden" name="action" id="action" value="add">
                <input type="hidden" name="id" id="doctorId">
                <input type="hidden" name="existing_photo" id="existingPhoto">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Фамилия *</label>
                        <input type="text" name="last_name" id="last_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Имя *</label>
                        <input type="text" name="first_name" id="first_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Отчество</label>
                        <input type="text" name="middle_name" id="middle_name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Специализация *</label>
                        <select name="specialization_id" id="specialization_id" class="form-select" required>
                            <?php foreach ($specializations as $spec): ?>
                            <option value="<?php echo $spec['id']; ?>"><?php echo $spec['title']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Стаж (лет)</label>
                        <input type="number" name="experience" id="experience" class="form-control" min="0">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Фото</label>
                    <input type="file" name="photo" id="photo_input" class="form-control" accept="image/*" onchange="previewImage(this)">
                    <div id="photo_preview" style="margin-top: 10px; display: none;">
                        <img id="preview_img" src="" style="max-width: 150px; border-radius: 5px;">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Биография</label>
                    <textarea name="bio" id="bio" class="form-textarea" rows="4"></textarea>
                </div>
                <div class="form-check">
                    <input type="checkbox" name="is_published" id="is_published" checked>
                    <label for="is_published">Опубликовать</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal()">Отмена</button>
                <button type="submit" class="btn btn-primary">💾 Сохранить</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('doctorModal').classList.add('active');
    document.getElementById('modalTitle').textContent = 'Добавить врача';
    document.getElementById('action').value = 'add';
    document.getElementById('doctorId').value = '';
    document.getElementById('existingPhoto').value = '';
    ['last_name','first_name','middle_name','experience','bio'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('specialization_id').selectedIndex = 0;
    document.getElementById('is_published').checked = true;
    document.getElementById('photo_preview').style.display = 'none';
    document.getElementById('photo_input').value = '';
}

function closeModal() { document.getElementById('doctorModal').classList.remove('active'); }

function editDoctor(d) {
    document.getElementById('modalTitle').textContent = 'Редактировать';
    document.getElementById('action').value = 'edit';
    document.getElementById('doctorId').value = d.id;
    document.getElementById('existingPhoto').value = d.photo || '';
    document.getElementById('last_name').value = d.last_name;
    document.getElementById('first_name').value = d.first_name;
    document.getElementById('middle_name').value = d.middle_name || '';
    document.getElementById('specialization_id').value = d.specialization_id;
    document.getElementById('experience').value = d.experience;
    document.getElementById('bio').value = d.bio || '';
    document.getElementById('is_published').checked = d.is_published == 1;
    if (d.photo) {
        document.getElementById('preview_img').src = '../' + d.photo;
        document.getElementById('photo_preview').style.display = 'block';
    }
    document.getElementById('doctorModal').classList.add('active');
}

function previewImage(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('preview_img').src = e.target.result;
            document.getElementById('photo_preview').style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php include __DIR__ . '/footer.php'; ?>