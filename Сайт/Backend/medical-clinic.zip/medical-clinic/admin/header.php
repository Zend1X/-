<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админ-панель</title>
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="admin-header">
        <h2>👋 <?php echo htmlspecialchars($_SESSION['user_login']); ?></h2>
        <a href="logout.php" class="logout-btn">Выйти</a>
    </div>
    
    <div class="admin-nav">
        <a href="index.php">📊 Главная</a>
        <a href="appointments.php">📅 Заявки</a>
        <a href="doctors.php">👨‍⚕️ Врачи</a>
        <a href="services.php">💉 Услуги</a>
        <a href="feedback.php">💬 Обращения</a>
        <a href="news.php">📰 Новости</a>
        <a href="../">🏠 На сайт</a>
    </div>