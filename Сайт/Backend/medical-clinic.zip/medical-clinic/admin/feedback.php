<?php
require_once __DIR__ . '/../config/database.php';
include __DIR__ . '/header.php';

$db = new Database();
$conn = $db->getConnection();

if (isset($_POST['update_status'])) {
    $stmt = $conn->prepare("UPDATE feedback SET status_id = ? WHERE id = ?");
    $stmt->execute([(int)$_POST['status_id'], (int)$_POST['feedback_id']]);
}

// Фильтры
$where = [];
$params = [];

if (!empty($_GET['status'])) {
    $where[] = "fs.id = ?";
    $params[] = (int)$_GET['status'];
}

if (!empty($_GET['search'])) {
    $where[] = "(f.name LIKE ? OR f.email LIKE ? OR f.phone LIKE ? OR f.subject LIKE ?)";
    $s = "%{$_GET['search']}%";
    $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
}

$where_clause = count($where) ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT f.*, fs.name as status_name, fs.code as status_code 
        FROM feedback f JOIN feedback_statuses fs ON f.status_id = fs.id 
        $where_clause ORDER BY f.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
$statuses = $conn->query("SELECT * FROM feedback_statuses")->fetchAll();
?>

<div class="admin-content">
    <div class="card">
        <div class="card-header"><h3>Обращения (<?php echo count($feedbacks); ?>)</h3></div>
        <div class="card-body">
            <form method="GET" class="search-box">
                <input type="text" name="search" placeholder="🔍 Поиск по имени, email, теме..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="flex: 2;">
                <select name="status" class="form-select" style="width: 160px;">
                    <option value="">Все статусы</option>
                    <?php foreach ($statuses as $st): ?>
                    <option value="<?php echo $st['id']; ?>" <?php echo ($_GET['status'] ?? '') == $st['id'] ? 'selected' : ''; ?>><?php echo $st['name']; ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary">🔍</button>
                <?php if (!empty($_GET)): ?>
                <a href="feedback.php" class="btn btn-outline">✖</a>
                <?php endif; ?>
            </form>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th><th>Имя</th><th>Контакты</th><th>Тема</th><th>Сообщение</th><th>Дата</th><th>Статус</th><th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($feedbacks as $fb): ?>
                        <tr>
                            <td>#<?php echo $fb['id']; ?></td>
                            <td><?php echo htmlspecialchars($fb['name']); ?></td>
                            <td>📞 <?php echo htmlspecialchars($fb['phone'] ?: '—'); ?><br>✉️ <?php echo htmlspecialchars($fb['email']); ?></td>
                            <td><?php echo htmlspecialchars($fb['subject'] ?: '—'); ?></td>
                            <td>
                                <div style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo htmlspecialchars($fb['message']); ?>
                                </div>
                                <button onclick="alert(<?php echo htmlspecialchars(json_encode($fb['message'])); ?>)" class="btn btn-info btn-sm" style="margin-top: 5px;">Читать</button>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($fb['created_at'])); ?></td>
                            <td><span class="badge badge-<?php echo $fb['status_code']; ?>"><?php echo $fb['status_name']; ?></span></td>
                            <td>
                                <form method="POST" style="display: flex; gap: 5px;">
                                    <input type="hidden" name="feedback_id" value="<?php echo $fb['id']; ?>">
                                    <select name="status_id" class="form-select" style="width: 120px; padding: 5px; font-size: 12px;">
                                        <?php foreach ($statuses as $st): ?>
                                        <option value="<?php echo $st['id']; ?>" <?php echo $fb['status_id'] == $st['id'] ? 'selected' : ''; ?>><?php echo $st['name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="update_status" class="btn btn-primary btn-sm">✓</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>