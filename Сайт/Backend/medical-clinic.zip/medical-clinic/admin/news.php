<?php
require_once __DIR__ . '/../config/database.php';
include __DIR__ . '/header.php';

$db = new Database();
$conn = $db->getConnection();

$message = '';
$message_type = '';

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $title = trim($_POST['title']);
        $announce = trim($_POST['announce']);
        $body = $_POST['body'];
        $published_at = !empty($_POST['published_at']) ? $_POST['published_at'] : date('Y-m-d H:i:s');
        $is_visible = isset($_POST['is_visible']) ? 1 : 0;
        
        $image = null;
        if (!empty($_FILES['image']['name'])) {
            $target_dir = "../images/news/";
            if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
            $image_name = time() . '_' . basename($_FILES['image']['name']);
            $image = 'images/news/' . $image_name;
            move_uploaded_file($_FILES['image']['tmp_name'], $target_dir . $image_name);
        }
        
        if ($_POST['action'] === 'add') {
            $stmt = $conn->prepare("INSERT INTO news (title, announce, body, image, published_at, is_visible) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $announce, $body, $image, $published_at, $is_visible]);
            $message = 'Новость добавлена';
            $message_type = 'success';
        } elseif ($_POST['action'] === 'edit') {
            $id = (int)$_POST['id'];
            if ($image) {
                $stmt = $conn->prepare("UPDATE news SET title=?, announce=?, body=?, image=?, published_at=?, is_visible=? WHERE id=?");
                $stmt->execute([$title, $announce, $body, $image, $published_at, $is_visible, $id]);
            } else {
                $stmt = $conn->prepare("UPDATE news SET title=?, announce=?, body=?, published_at=?, is_visible=? WHERE id=?");
                $stmt->execute([$title, $announce, $body, $published_at, $is_visible, $id]);
            }
            $message = 'Новость обновлена';
            $message_type = 'success';
        }
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $conn->prepare("DELETE FROM news WHERE id = ?")->execute([$id]);
        $message = 'Новость удалена';
        $message_type = 'success';
    }
}

// Фильтры
$where = [];
$params = [];

if (!empty($_GET['search'])) {
    $where[] = "(n.title LIKE ? OR n.announce LIKE ? OR n.body LIKE ?)";
    $search = "%{$_GET['search']}%";
    $params[] = $search; $params[] = $search; $params[] = $search;
}

if (isset($_GET['visible']) && $_GET['visible'] !== '') {
    $where[] = "n.is_visible = ?";
    $params[] = (int)$_GET['visible'];
}

if (!empty($_GET['date_from'])) {
    $where[] = "DATE(n.published_at) >= ?";
    $params[] = $_GET['date_from'];
}

if (!empty($_GET['date_to'])) {
    $where[] = "DATE(n.published_at) <= ?";
    $params[] = $_GET['date_to'];
}

$where_clause = count($where) ? "WHERE " . implode(" AND ", $where) : "";

// Пагинация
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

$count_sql = "SELECT COUNT(*) FROM news n $where_clause";
$count_stmt = $conn->prepare($count_sql);
$count_stmt->execute($params);
$total = $count_stmt->fetchColumn();
$total_pages = ceil($total / $per_page);

$sql = "SELECT n.* FROM news n $where_clause ORDER BY n.published_at DESC LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$news_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="admin-content">
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h3>Новости (<?php echo $total; ?>)</h3>
            <button onclick="openModal()" class="btn btn-primary">+ Добавить новость</button>
        </div>
        <div class="card-body">
            <!-- Фильтры -->
            <form method="GET" class="search-box" style="flex-wrap: wrap;">
                <input type="text" name="search" placeholder="🔍 Поиск по заголовку, анонсу или тексту..." 
                       value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="flex: 2; min-width: 200px;">
                
                <select name="visible" class="form-select" style="width: 150px;">
                    <option value="">Все статусы</option>
                    <option value="1" <?php echo ($_GET['visible'] ?? '') === '1' ? 'selected' : ''; ?>>Видимые</option>
                    <option value="0" <?php echo ($_GET['visible'] ?? '') === '0' ? 'selected' : ''; ?>>Скрытые</option>
                </select>
                
                <input type="date" name="date_from" value="<?php echo $_GET['date_from'] ?? ''; ?>" class="form-control" style="width: 150px;" placeholder="С даты">
                <input type="date" name="date_to" value="<?php echo $_GET['date_to'] ?? ''; ?>" class="form-control" style="width: 150px;" placeholder="По дату">
                
                <button type="submit" class="btn btn-primary">🔍</button>
                <?php if (!empty($_GET)): ?>
                <a href="news.php" class="btn btn-outline">✖ Сбросить</a>
                <?php endif; ?>
            </form>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Фото</th>
                            <th>Заголовок</th>
                            <th>Анонс</th>
                            <th>Дата публикации</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($news_list as $item): ?>
                        <tr>
                            <td>
                                <?php if ($item['image']): ?>
                                <img src="../<?php echo $item['image']; ?>" style="width: 60px; height: 40px; object-fit: cover; border-radius: 5px;">
                                <?php else: ?>
                                <span style="color: #999;">—</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($item['title']); ?></strong></td>
                            <td>
                                <div style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo htmlspecialchars($item['announce'] ?: '—'); ?>
                                </div>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($item['published_at'])); ?></td>
                            <td>
                                <span class="badge <?php echo $item['is_visible'] ? 'badge-confirmed' : 'badge-rejected'; ?>">
                                    <?php echo $item['is_visible'] ? 'Видна' : 'Скрыта'; ?>
                                </span>
                            </td>
                            <td>
                                <button onclick='editNews(<?php echo json_encode($item); ?>)' class="btn btn-info btn-sm">✏️</button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                    <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Удалить новость?')">🗑️</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Пагинация -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php 
                $query_params = $_GET;
                unset($query_params['page']);
                $query_string = http_build_query($query_params);
                ?>
                <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&<?php echo $query_string; ?>">←</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&<?php echo $query_string; ?>" class="<?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&<?php echo $query_string; ?>">→</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Модальное окно -->
<div class="modal-overlay" id="newsModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modalTitle">Добавить новость</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <input type="hidden" name="action" id="action" value="add">
                <input type="hidden" name="id" id="newsId">
                
                <div class="form-group">
                    <label class="form-label">Заголовок *</label>
                    <input type="text" name="title" id="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Анонс *</label>
                    <textarea name="announce" id="announce" class="form-textarea" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Полный текст</label>
                    <textarea name="body" id="body" class="form-textarea" rows="5"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Изображение</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
                <div class="form-group">
                    <label class="form-label">Дата публикации</label>
                    <input type="datetime-local" name="published_at" id="published_at" class="form-control">
                </div>
                <div class="form-check">
                    <input type="checkbox" name="is_visible" id="is_visible" checked>
                    <label for="is_visible">Опубликовать на сайте</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal()">Отмена</button>
                <button type="submit" class="btn btn-primary">💾 Сохранить</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('newsModal').classList.add('active');
    document.getElementById('modalTitle').textContent = 'Добавить новость';
    document.getElementById('action').value = 'add';
    document.getElementById('newsId').value = '';
    document.getElementById('title').value = '';
    document.getElementById('announce').value = '';
    document.getElementById('body').value = '';
    document.getElementById('published_at').value = '';
    document.getElementById('is_visible').checked = true;
}

function closeModal() { document.getElementById('newsModal').classList.remove('active'); }

function editNews(n) {
    document.getElementById('modalTitle').textContent = 'Редактировать новость';
    document.getElementById('action').value = 'edit';
    document.getElementById('newsId').value = n.id;
    document.getElementById('title').value = n.title;
    document.getElementById('announce').value = n.announce || '';
    document.getElementById('body').value = n.body || '';
    document.getElementById('published_at').value = n.published_at ? n.published_at.replace(' ', 'T') : '';
    document.getElementById('is_visible').checked = n.is_visible == 1;
    document.getElementById('newsModal').classList.add('active');
}
</script>

<?php include __DIR__ . '/footer.php'; ?>