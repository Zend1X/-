<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Очищаем сессию
$_SESSION = array();
session_destroy();

// Перенаправляем на страницу входа
header('Location: login.php');
exit();
?>