<?php
$current_admin_page = basename($_SERVER['PHP_SELF']);
?>
<div class="admin-sidebar">
    <div class="sidebar-header">
        <h2>МедЦентр</h2>
        <p>Панель управления</p>
    </div>
    
    <nav class="sidebar-nav">
        <a href="<?php echo BASE_PATH; ?>/admin/index.php" class="<?php echo $current_admin_page == 'index.php' ? 'active' : ''; ?>">
            <span class="nav-icon">📊</span>
            <span>Главная</span>
        </a>
        <a href="<?php echo BASE_PATH; ?>/admin/appointments.php" class="<?php echo $current_admin_page == 'appointments.php' ? 'active' : ''; ?>">
            <span class="nav-icon">📅</span>
            <span>Заявки</span>
        </a>
        <a href="<?php echo BASE_PATH; ?>/admin/doctors.php" class="<?php echo $current_admin_page == 'doctors.php' ? 'active' : ''; ?>">
            <span class="nav-icon">👨‍⚕️</span>
            <span>Врачи</span>
        </a>
        <a href="<?php echo BASE_PATH; ?>/admin/services.php" class="<?php echo $current_admin_page == 'services.php' ? 'active' : ''; ?>">
            <span class="nav-icon">💉</span>
            <span>Услуги</span>
        </a>
        <a href="<?php echo BASE_PATH; ?>/admin/feedback.php" class="<?php echo $current_admin_page == 'feedback.php' ? 'active' : ''; ?>">
            <span class="nav-icon">💬</span>
            <span>Обращения</span>
        </a>
        <a href="<?php echo BASE_PATH; ?>/admin/news.php" class="<?php echo $current_admin_page == 'news.php' ? 'active' : ''; ?>">
            <span class="nav-icon">📰</span>
            <span>Новости</span>
        </a>
    </nav>
    
    <div class="sidebar-footer">
        <a href="<?php echo BASE_PATH; ?>/">🏠 На сайт</a>
        <a href="<?php echo BASE_PATH; ?>/admin/logout.php">🚪 Выйти</a>
    </div>
</div>