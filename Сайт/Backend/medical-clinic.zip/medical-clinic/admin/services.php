<?php
require_once __DIR__ . '/../config/database.php';
include __DIR__ . '/header.php';

$db = new Database();
$conn = $db->getConnection();

$message = '';
$message_type = '';

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $title = trim($_POST['title']);
        $category_id = (int)$_POST['category_id'];
        $short_desc = trim($_POST['short_desc']);
        $full_desc = $_POST['full_desc'];
        $price = (float)$_POST['price'];
        $duration = (int)$_POST['duration'];
        $is_published = isset($_POST['is_published']) ? 1 : 0;
        
        if ($_POST['action'] === 'add') {
            $stmt = $conn->prepare("INSERT INTO services (title, category_id, short_desc, full_desc, price, duration, is_published) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $category_id, $short_desc, $full_desc, $price, $duration, $is_published]);
            $message = 'Услуга добавлена';
            $message_type = 'success';
        } elseif ($_POST['action'] === 'edit') {
            $id = (int)$_POST['id'];
            $stmt = $conn->prepare("UPDATE services SET title=?, category_id=?, short_desc=?, full_desc=?, price=?, duration=?, is_published=? WHERE id=?");
            $stmt->execute([$title, $category_id, $short_desc, $full_desc, $price, $duration, $is_published, $id]);
            $message = 'Услуга обновлена';
            $message_type = 'success';
        }
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $conn->prepare("DELETE FROM services WHERE id = ?")->execute([$id]);
        $message = 'Услуга удалена';
        $message_type = 'success';
    }
}

// Фильтры
$where = [];
$params = [];

if (!empty($_GET['category'])) {
    $where[] = "s.category_id = ?";
    $params[] = (int)$_GET['category'];
}

if (!empty($_GET['search'])) {
    $where[] = "(s.title LIKE ? OR s.short_desc LIKE ?)";
    $search = "%{$_GET['search']}%";
    $params[] = $search;
    $params[] = $search;
}

if (isset($_GET['published']) && $_GET['published'] !== '') {
    $where[] = "s.is_published = ?";
    $params[] = (int)$_GET['published'];
}

if (!empty($_GET['price_from'])) {
    $where[] = "s.price >= ?";
    $params[] = (float)$_GET['price_from'];
}

if (!empty($_GET['price_to'])) {
    $where[] = "s.price <= ?";
    $params[] = (float)$_GET['price_to'];
}

$where_clause = count($where) ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT s.*, sc.title as category_name 
        FROM services s 
        JOIN service_categories sc ON s.category_id = sc.id 
        $where_clause 
        ORDER BY sc.sort_order, s.title";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

$categories = $conn->query("SELECT * FROM service_categories WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
?>

<div class="admin-content">
    <?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h3>Услуги (<?php echo count($services); ?>)</h3>
            <button onclick="openModal()" class="btn btn-primary">+ Добавить услугу</button>
        </div>
        <div class="card-body">
            <!-- Фильтры -->
            <form method="GET" class="search-box" style="flex-wrap: wrap;">
                <input type="text" name="search" placeholder="🔍 Поиск по названию или описанию..." 
                       value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="flex: 2; min-width: 200px;">
                
                <select name="category" class="form-select" style="width: 180px;">
                    <option value="">Все категории</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo ($_GET['category'] ?? '') == $cat['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['title']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="published" class="form-select" style="width: 150px;">
                    <option value="">Все статусы</option>
                    <option value="1" <?php echo ($_GET['published'] ?? '') === '1' ? 'selected' : ''; ?>>Опубликованные</option>
                    <option value="0" <?php echo ($_GET['published'] ?? '') === '0' ? 'selected' : ''; ?>>Скрытые</option>
                </select>
                
                <input type="number" name="price_from" placeholder="Цена от" 
                       value="<?php echo htmlspecialchars($_GET['price_from'] ?? ''); ?>" class="form-control" style="width: 120px;">
                <input type="number" name="price_to" placeholder="Цена до" 
                       value="<?php echo htmlspecialchars($_GET['price_to'] ?? ''); ?>" class="form-control" style="width: 120px;">
                
                <button type="submit" class="btn btn-primary">🔍</button>
                <?php if (!empty($_GET)): ?>
                <a href="services.php" class="btn btn-outline">✖ Сбросить</a>
                <?php endif; ?>
            </form>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Название</th>
                            <th>Категория</th>
                            <th>Цена</th>
                            <th>Длительность</th>
                            <th>Описание</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($services as $service): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($service['title']); ?></strong></td>
                            <td><?php echo htmlspecialchars($service['category_name']); ?></td>
                            <td><?php echo number_format($service['price'], 0, '.', ' '); ?> ₽</td>
                            <td><?php echo $service['duration']; ?> мин</td>
                            <td>
                                <div style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo htmlspecialchars($service['short_desc'] ?: '—'); ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge <?php echo $service['is_published'] ? 'badge-confirmed' : 'badge-rejected'; ?>">
                                    <?php echo $service['is_published'] ? 'Опубликована' : 'Скрыта'; ?>
                                </span>
                            </td>
                            <td>
                                <button onclick='editService(<?php echo json_encode($service); ?>)' class="btn btn-info btn-sm">✏️</button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
                                    <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Удалить услугу?')">🗑️</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно -->
<div class="modal-overlay" id="serviceModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="modalTitle">Добавить услугу</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="action" id="action" value="add">
                <input type="hidden" name="id" id="serviceId">
                
                <div class="form-group">
                    <label class="form-label">Название *</label>
                    <input type="text" name="title" id="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Категория *</label>
                    <select name="category_id" id="category_id" class="form-select" required>
                        <option value="">Выберите категорию</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['title']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Цена (₽)</label>
                        <input type="number" name="price" id="price" class="form-control" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Длительность (мин)</label>
                        <input type="number" name="duration" id="duration" class="form-control" min="0" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Краткое описание</label>
                    <textarea name="short_desc" id="short_desc" class="form-textarea" rows="2" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Полное описание</label>
                    <textarea name="full_desc" id="full_desc" class="form-textarea" rows="3"></textarea>
                </div>
                <div class="form-check">
                    <input type="checkbox" name="is_published" id="is_published" checked>
                    <label for="is_published">Опубликовать на сайте</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal()">Отмена</button>
                <button type="submit" class="btn btn-primary">💾 Сохранить</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('serviceModal').classList.add('active');
    document.getElementById('modalTitle').textContent = 'Добавить услугу';
    document.getElementById('action').value = 'add';
    document.getElementById('serviceId').value = '';
    document.getElementById('title').value = '';
    document.getElementById('category_id').value = '';
    document.getElementById('price').value = '';
    document.getElementById('duration').value = '';
    document.getElementById('short_desc').value = '';
    document.getElementById('full_desc').value = '';
    document.getElementById('is_published').checked = true;
}

function closeModal() { document.getElementById('serviceModal').classList.remove('active'); }

function editService(s) {
    document.getElementById('modalTitle').textContent = 'Редактировать услугу';
    document.getElementById('action').value = 'edit';
    document.getElementById('serviceId').value = s.id;
    document.getElementById('title').value = s.title;
    document.getElementById('category_id').value = s.category_id;
    document.getElementById('price').value = s.price;
    document.getElementById('duration').value = s.duration;
    document.getElementById('short_desc').value = s.short_desc || '';
    document.getElementById('full_desc').value = s.full_desc || '';
    document.getElementById('is_published').checked = s.is_published == 1;
    document.getElementById('serviceModal').classList.add('active');
}
</script>

<?php include __DIR__ . '/footer.php'; ?>