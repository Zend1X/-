<?php
require_once __DIR__ . '/../config/database.php';
include __DIR__ . '/header.php';

$db = new Database();
$conn = $db->getConnection();

// Обновление статуса
if (isset($_POST['update_status'])) {
    $appointment_id = (int)$_POST['appointment_id'];
    $status_id = (int)$_POST['status_id'];
    $stmt = $conn->prepare("UPDATE appointments SET status_id = ? WHERE id = ?");
    $stmt->execute([$status_id, $appointment_id]);
}

// Фильтры
$where = [];
$params = [];

if (!empty($_GET['status'])) {
    $where[] = "ast.id = ?";
    $params[] = (int)$_GET['status'];
}

if (!empty($_GET['search'])) {
    $where[] = "(a.patient_name LIKE ? OR a.phone LIKE ? OR a.email LIKE ?)";
    $search = "%{$_GET['search']}%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
}

if (!empty($_GET['doctor'])) {
    $where[] = "a.doctor_id = ?";
    $params[] = (int)$_GET['doctor'];
}

if (!empty($_GET['date_from'])) {
    $where[] = "DATE(a.created_at) >= ?";
    $params[] = $_GET['date_from'];
}

if (!empty($_GET['date_to'])) {
    $where[] = "DATE(a.created_at) <= ?";
    $params[] = $_GET['date_to'];
}

$where_clause = count($where) ? "WHERE " . implode(" AND ", $where) : "";

// Пагинация
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

$count_sql = "SELECT COUNT(*) FROM appointments a JOIN appointment_statuses ast ON a.status_id = ast.id $where_clause";
$count_stmt = $conn->prepare($count_sql);
$count_stmt->execute($params);
$total = $count_stmt->fetchColumn();
$total_pages = ceil($total / $per_page);

$sql = "SELECT a.*, d.last_name, d.first_name, s.title as service_title, 
        ast.name as status_name, ast.code as status_code
        FROM appointments a 
        LEFT JOIN doctors d ON a.doctor_id = d.id 
        LEFT JOIN services s ON a.service_id = s.id 
        JOIN appointment_statuses ast ON a.status_id = ast.id 
        $where_clause 
        ORDER BY a.created_at DESC 
        LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$statuses = $conn->query("SELECT * FROM appointment_statuses")->fetchAll();
$doctors = $conn->query("SELECT id, last_name, first_name FROM doctors ORDER BY last_name")->fetchAll();
?>

<div class="admin-content">
    <div class="card">
        <div class="card-header">
            <h3>Заявки на приём (<?php echo $total; ?>)</h3>
        </div>
        <div class="card-body">
            <!-- Фильтры -->
            <form method="GET" class="search-box" style="flex-wrap: wrap;">
                <input type="text" name="search" placeholder="🔍 Поиск по имени, телефону или email..." 
                       value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="flex: 2;">
                
                <select name="status" class="form-select" style="width: 160px;">
                    <option value="">Все статусы</option>
                    <?php foreach ($statuses as $status): ?>
                    <option value="<?php echo $status['id']; ?>" <?php echo ($_GET['status'] ?? '') == $status['id'] ? 'selected' : ''; ?>>
                        <?php echo $status['name']; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="doctor" class="form-select" style="width: 180px;">
                    <option value="">Все врачи</option>
                    <?php foreach ($doctors as $doc): ?>
                    <option value="<?php echo $doc['id']; ?>" <?php echo ($_GET['doctor'] ?? '') == $doc['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($doc['last_name'] . ' ' . $doc['first_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <input type="date" name="date_from" value="<?php echo $_GET['date_from'] ?? ''; ?>" class="form-control" style="width: 150px;" placeholder="С даты">
                <input type="date" name="date_to" value="<?php echo $_GET['date_to'] ?? ''; ?>" class="form-control" style="width: 150px;" placeholder="По дату">
                
                <button type="submit" class="btn btn-primary">🔍 Найти</button>
                <?php if (!empty($_GET)): ?>
                <a href="appointments.php" class="btn btn-outline">✖ Сбросить</a>
                <?php endif; ?>
            </form>
            
            <!-- Таблица -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th><a href="?sort=id">ID</a></th>
                            <th>Пациент</th>
                            <th>Контакты</th>
                            <th>Врач</th>
                            <th>Услуга</th>
                            <th>Желаемая дата</th>
                            <th>Дата создания</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($appointments as $apt): ?>
                        <tr>
                            <td>#<?php echo $apt['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($apt['patient_name']); ?></strong>
                                <?php if ($apt['comment']): ?>
                                <br><small style="color: #999;"><?php echo htmlspecialchars(mb_substr($apt['comment'], 0, 50)); ?>...</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                📞 <?php echo htmlspecialchars($apt['phone']); ?>
                                <?php if ($apt['email']): ?>
                                <br>✉️ <?php echo htmlspecialchars($apt['email']); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $apt['last_name'] ? htmlspecialchars($apt['last_name'] . ' ' . $apt['first_name']) : '<span style="color:#999;">—</span>'; ?></td>
                            <td><?php echo $apt['service_title'] ? htmlspecialchars($apt['service_title']) : '<span style="color:#999;">—</span>'; ?></td>
                            <td><?php echo $apt['desired_date'] ? date('d.m.Y H:i', strtotime($apt['desired_date'])) : '<span style="color:#999;">—</span>'; ?></td>
                            <td><?php echo date('d.m.Y H:i', strtotime($apt['created_at'])); ?></td>
                            <td><span class="badge badge-<?php echo $apt['status_code']; ?>"><?php echo $apt['status_name']; ?></span></td>
                            <td>
                                <form method="POST" style="display: flex; gap: 5px;">
                                    <input type="hidden" name="appointment_id" value="<?php echo $apt['id']; ?>">
                                    <select name="status_id" class="form-select" style="width: 130px; padding: 5px; font-size: 12px;">
                                        <?php foreach ($statuses as $st): ?>
                                        <option value="<?php echo $st['id']; ?>" <?php echo $apt['status_id'] == $st['id'] ? 'selected' : ''; ?>>
                                            <?php echo $st['name']; ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="update_status" class="btn btn-primary btn-sm">✓</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Пагинация -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php $query_string = http_build_query(array_filter($_GET)); ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&<?php echo $query_string; ?>" class="<?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>