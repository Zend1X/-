<?php
require_once __DIR__ . '/../config/database.php';
include __DIR__ . '/header.php';

$db = new Database();
$conn = $db->getConnection();

$new_appointments = $conn->query("SELECT COUNT(*) FROM appointments WHERE status_id = 1")->fetchColumn();
$total_appointments = $conn->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$total_doctors = $conn->query("SELECT COUNT(*) FROM doctors")->fetchColumn();
$total_services = $conn->query("SELECT COUNT(*) FROM services")->fetchColumn();
$new_feedback = $conn->query("SELECT COUNT(*) FROM feedback WHERE status_id = 1")->fetchColumn();
?>

<div class="admin-content">
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?php echo $new_appointments; ?></div>
            <div class="stat-label">Новых заявок</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?php echo $total_appointments; ?></div>
            <div class="stat-label">Всего заявок</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?php echo $new_feedback; ?></div>
            <div class="stat-label">Новых обращений</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?php echo $total_doctors; ?></div>
            <div class="stat-label">Врачей</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?php echo $total_services; ?></div>
            <div class="stat-label">Услуг</div>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h3>Последние заявки</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Пациент</th>
                            <th>Телефон</th>
                            <th>Дата</th>
                            <th>Статус</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT a.*, s.name as status_name, s.code as status_code 
                                 FROM appointments a 
                                 JOIN appointment_statuses s ON a.status_id = s.id 
                                 ORDER BY a.created_at DESC LIMIT 10";
                        $stmt = $conn->query($query);
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                        ?>
                        <tr>
                            <td>#<?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['patient_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['phone']); ?></td>
                            <td><?php echo date('d.m.Y H:i', strtotime($row['created_at'])); ?></td>
                            <td><span class="badge badge-<?php echo $row['status_code']; ?>"><?php echo $row['status_name']; ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>