<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

// Получаем все специализации с врачами
$spec_query = "SELECT * FROM specializations WHERE is_active = 1";
$spec_stmt = $conn->prepare($spec_query);
$spec_stmt->execute();
$specializations = $spec_stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<!-- Хлебные крошки -->
<div class="breadcrumbs">
    <div class="container">
        <a href="<?php echo BASE_PATH; ?>/">Главная</a>
        <span>/</span>
        Врачи
    </div>
</div>

<section class="section">
    <div class="container">
        <h1 class="section-title">Наши врачи</h1>
        
        <?php foreach ($specializations as $spec): ?>
            <?php
            $doctors_query = "SELECT d.*, s.title as specialization_name 
                             FROM doctors d 
                             JOIN specializations s ON d.specialization_id = s.id 
                             WHERE d.specialization_id = ? AND d.is_published = 1";
            $doctors_stmt = $conn->prepare($doctors_query);
            $doctors_stmt->execute([$spec['id']]);
            $doctors = $doctors_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($doctors) > 0):
            ?>
            <div style="margin-bottom: 60px;">
                <h2 style="margin-bottom: 30px; color: #263238;"><?php echo htmlspecialchars($spec['title']); ?></h2>
                <div class="doctors-grid">
                    <?php foreach ($doctors as $doctor): ?>
                    <div class="doctor-card">
                        <img src="<?php echo BASE_PATH . '/' . ($doctor['photo'] ?: 'images/default-doctor.jpg'); ?>" 
                             alt="<?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name']); ?>"
                             class="doctor-photo">
                        <h3 class="doctor-name">
                            <?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name']); ?>
                        </h3>
                        <p class="doctor-specialty"><?php echo htmlspecialchars($spec['title']); ?></p>
                        <p class="doctor-experience">Стаж: <?php echo $doctor['experience']; ?> лет</p>
                        <?php if ($doctor['bio']): ?>
                        <p style="color: #78909c; padding: 0 20px; margin-bottom: 15px; font-size: 14px;">
                            <?php echo mb_substr(strip_tags($doctor['bio']), 0, 100) . '...'; ?>
                        </p>
                        <?php endif; ?>
                        <a href="<?php echo BASE_PATH; ?>/doctor.php?id=<?php echo $doctor['id']; ?>" class="btn btn-outline">Подробнее</a>
                        <a href="<?php echo BASE_PATH; ?>/appointment.php?doctor_id=<?php echo $doctor['id']; ?>" class="btn btn-primary">Записаться</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>