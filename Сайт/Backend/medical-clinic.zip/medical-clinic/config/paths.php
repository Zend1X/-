<?php
// Определяем базовый путь автоматически
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$script_dir = dirname($_SERVER['SCRIPT_NAME']);
$base_path = rtrim($script_dir, '/\\');
$base_url = $protocol . $host . $base_path;

// Если сайт в корне, base_path будет пустым
if ($base_path == '') {
    $base_path = '';
}

define('BASE_PATH', $base_path);
define('BASE_URL', $base_url);
?>