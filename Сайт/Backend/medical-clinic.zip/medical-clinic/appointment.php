<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

$message = '';
$message_type = '';

// Получаем предвыбранного врача и услугу из GET-параметров
$selected_doctor_id = isset($_GET['doctor_id']) ? (int)$_GET['doctor_id'] : 0;
$selected_service_id = isset($_GET['service_id']) ? (int)$_GET['service_id'] : 0;

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_name = sanitize($_POST['patient_name']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $desired_date = $_POST['desired_date'];
    $comment = sanitize($_POST['comment']);
    $doctor_id = !empty($_POST['doctor_id']) ? (int)$_POST['doctor_id'] : null;
    $service_id = !empty($_POST['service_id']) ? (int)$_POST['service_id'] : null;
    
    $errors = [];
    
    if (empty($patient_name)) {
        $errors[] = 'Введите ваше имя';
    }
    
    if (!validatePhone($phone)) {
        $errors[] = 'Введите корректный номер телефона';
    }
    
    if (!empty($email) && !validateEmail($email)) {
        $errors[] = 'Введите корректный email';
    }
    
    if (empty($errors)) {
        $query = "INSERT INTO appointments (patient_name, phone, email, desired_date, comment, doctor_id, service_id, status_id) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
        $stmt = $conn->prepare($query);
        
        if ($stmt->execute([$patient_name, $phone, $email, $desired_date, $comment, $doctor_id, $service_id])) {
            $message = 'Ваша заявка успешно отправлена! Мы свяжемся с вами в ближайшее время.';
            $message_type = 'success';
        } else {
            $message = 'Произошла ошибка при отправке заявки. Пожалуйста, попробуйте позже.';
            $message_type = 'error';
        }
    } else {
        $message = implode('<br>', $errors);
        $message_type = 'error';
    }
}

// Получаем врачей для выпадающего списка
$doctors_query = "SELECT d.id, d.last_name, d.first_name, d.middle_name, s.title as specialization 
                 FROM doctors d 
                 JOIN specializations s ON d.specialization_id = s.id 
                 WHERE d.is_published = 1";
$doctors_stmt = $conn->prepare($doctors_query);
$doctors_stmt->execute();
$doctors = $doctors_stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем услуги
$services_query = "SELECT s.*, sc.title as category_name 
                  FROM services s 
                  JOIN service_categories sc ON s.category_id = sc.id 
                  WHERE s.is_published = 1";
$services_stmt = $conn->prepare($services_query);
$services_stmt->execute();
$services = $services_stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<!-- Хлебные крошки -->
<div class="breadcrumbs">
    <div class="container">
        <a href="<?php echo BASE_PATH; ?>/">Главная</a>
        <span>/</span>
        Запись на приём
    </div>
</div>

<section class="section">
    <div class="container">
        <h1 class="section-title">Запись на приём</h1>
        
        <?php if ($message): ?>
        <div class="<?php echo $message_type === 'success' ? 'success-message' : 'error-message'; ?>" style="margin-bottom: 30px;">
            <?php echo $message; ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" class="appointment-form" id="appointmentForm">
            <div id="formErrors" class="error-message" style="display: none;"></div>
            
            <div class="form-group">
                <label class="form-label" for="patient_name">Ваше имя *</label>
                <input type="text" id="patient_name" name="patient_name" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="phone">Телефон *</label>
                <input type="tel" id="phone" name="phone" class="form-control" placeholder="+7 (999) 123-45-67" required>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control">
            </div>
            
            <div class="form-group">
                <label class="form-label" for="doctor_id">Врач</label>
                <select id="doctor_id" name="doctor_id" class="form-select">
                    <option value="">Выберите врача</option>
                    <?php foreach ($doctors as $doctor): ?>
                    <option value="<?php echo $doctor['id']; ?>" <?php echo $selected_doctor_id == $doctor['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name'] . ' - ' . $doctor['specialization']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="service_id">Услуга</label>
                <select id="service_id" name="service_id" class="form-select">
                    <option value="">Выберите услугу</option>
                    <?php foreach ($services as $service): ?>
                    <option value="<?php echo $service['id']; ?>" <?php echo $selected_service_id == $service['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($service['title'] . ' - ' . number_format($service['price'], 0, '.', ' ') . ' ₽'); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="desired_date">Желаемая дата и время</label>
                <input type="datetime-local" id="desired_date" name="desired_date" class="form-control">
            </div>
            
            <div class="form-group">
                <label class="form-label" for="comment">Комментарий</label>
                <textarea id="comment" name="comment" class="form-textarea" placeholder="Опишите причину обращения или задайте вопрос"></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; font-size: 18px; padding: 15px;">
                Отправить заявку
            </button>
            
            <p style="text-align: center; margin-top: 20px; color: #78909c; font-size: 14px;">
                * Обязательные поля для заполнения
            </p>
        </form>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>