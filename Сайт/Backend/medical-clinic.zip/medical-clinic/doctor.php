<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

$doctor_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Получаем информацию о враче
$query = "SELECT d.*, s.title as specialization_name, s.description as specialization_desc 
          FROM doctors d 
          JOIN specializations s ON d.specialization_id = s.id 
          WHERE d.id = ? AND d.is_published = 1";
$stmt = $conn->prepare($query);
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$doctor) {
    header('Location: ' . BASE_PATH . '/doctors.php');
    exit();
}

// Получаем услуги врача
$services_query = "SELECT s.* FROM services s 
                  JOIN doctor_services ds ON s.id = ds.service_id 
                  WHERE ds.doctor_id = ? AND s.is_published = 1";
$services_stmt = $conn->prepare($services_query);
$services_stmt->execute([$doctor_id]);
$services = $services_stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<!-- Хлебные крошки -->
<div class="breadcrumbs">
    <div class="container">
        <a href="<?php echo BASE_PATH; ?>/">Главная</a>
        <span>/</span>
        <a href="<?php echo BASE_PATH; ?>/doctors.php">Врачи</a>
        <span>/</span>
        <?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name']); ?>
    </div>
</div>

<section class="section">
    <div class="container">
        <div class="doctor-detail">
            <!-- Фото врача -->
            <div style="text-align: center;">
                <img src="<?php echo BASE_PATH . '/' . ($doctor['photo'] ?: 'images/default-doctor.jpg'); ?>" 
                     alt="<?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name']); ?>"
                     class="doctor-detail-photo">
                <a href="<?php echo BASE_PATH; ?>/appointment.php?doctor_id=<?php echo $doctor['id']; ?>" 
                   class="btn btn-primary" style="width: 100%; margin-top: 20px;">
                    Записаться на приём
                </a>
            </div>
            
            <!-- Информация о враче -->
            <div>
                <h1 class="doctor-detail-name">
                    <?php echo htmlspecialchars($doctor['last_name'] . ' ' . $doctor['first_name'] . ' ' . $doctor['middle_name']); ?>
                </h1>
                <p class="doctor-detail-specialty">
                    <?php echo htmlspecialchars($doctor['specialization_name']); ?>
                </p>
                <p class="doctor-detail-experience">
                    Стаж работы: <strong><?php echo $doctor['experience']; ?> лет</strong>
                </p>
                
                <?php if ($doctor['bio']): ?>
                <div class="doctor-detail-bio">
                    <h3 style="margin-bottom: 15px; color: var(--dark);">О враче</h3>
                    <p><?php echo nl2br(htmlspecialchars($doctor['bio'])); ?></p>
                </div>
                <?php endif; ?>
                
                <?php if ($doctor['specialization_desc']): ?>
                <div style="margin-bottom: 40px; padding: 20px; background: var(--light); border-radius: var(--radius);">
                    <h3 style="margin-bottom: 10px; color: var(--dark);">О специализации</h3>
                    <p style="color: #555;"><?php echo nl2br(htmlspecialchars($doctor['specialization_desc'])); ?></p>
                </div>
                <?php endif; ?>
                
                <?php if (count($services) > 0): ?>
                <div>
                    <h3 style="margin-bottom: 20px; color: var(--dark);">Услуги врача</h3>
                    <div class="services-grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));">
                        <?php foreach ($services as $service): ?>
                        <div class="service-card">
                            <div class="service-content">
                                <h4 style="margin-bottom: 10px; color: var(--dark);">
                                    <?php echo htmlspecialchars($service['title']); ?>
                                </h4>
                                <p style="color: var(--gray); margin-bottom: 15px; font-size: 14px;">
                                    <?php echo htmlspecialchars($service['short_desc']); ?>
                                </p>
                                <div class="service-footer">
                                    <span class="service-price">
                                        <?php echo number_format($service['price'], 0, '.', ' '); ?> ₽
                                    </span>
                                    <span class="service-duration">⏱ <?php echo $service['duration']; ?> мин.</span>
                                </div>
                                <a href="<?php echo BASE_PATH; ?>/appointment.php?doctor_id=<?php echo $doctor['id']; ?>&service_id=<?php echo $service['id']; ?>" 
                                   class="btn btn-primary" style="margin-top: 15px; width: 100%;">
                                    Записаться
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>