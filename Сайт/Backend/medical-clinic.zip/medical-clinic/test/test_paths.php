<?php
require_once __DIR__ . '/config/paths.php';

echo "BASE_PATH: " . BASE_PATH . "<br>";
echo "BASE_URL: " . BASE_URL . "<br>";
echo "REQUEST_URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "SCRIPT_NAME: " . $_SERVER['SCRIPT_NAME'] . "<br>";
echo "DOCUMENT_ROOT: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Текущая директория: " . __DIR__ . "<br>";

echo "<h3>Проверка файлов:</h3>";
$files = [
    '/admin/index.php',
    '/admin/login.php',
    '/admin/logout.php'
];

foreach ($files as $file) {
    $full_path = __DIR__ . $file;
    echo $file . ": " . (file_exists($full_path) ? "✅ существует" : "❌ отсутствует") . "<br>";
}
?>