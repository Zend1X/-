<?php
echo "<h2>Проверка файлов</h2>";
$files = ['index.php', 'services.php', 'doctors.php', 'doctor.php', 'appointment.php', 'reviews.php', 'news.php', 'contacts.php'];
foreach ($files as $file) {
    echo $file . ": " . (file_exists($file) ? "✅ существует" : "❌ отсутствует") . "<br>";
}

echo "<h2>GET параметры</h2>";
echo "<pre>";
print_r($_GET);
echo "</pre>";

echo "<h2>SERVER</h2>";
echo "REQUEST_URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "SCRIPT_NAME: " . $_SERVER['SCRIPT_NAME'] . "<br>";
?>