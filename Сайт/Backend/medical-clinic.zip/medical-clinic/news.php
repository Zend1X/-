<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/paths.php';
require_once __DIR__ . '/includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

// Если передан ID - показываем детальную новость
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $news_id = (int)$_GET['id'];
    
    $query = "SELECT n.*, u.login as author_name 
              FROM news n 
              LEFT JOIN users u ON n.author_id = u.id 
              WHERE n.id = ? AND n.is_visible = 1";
    $stmt = $conn->prepare($query);
    $stmt->execute([$news_id]);
    $news_item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($news_item) {
        include __DIR__ . '/includes/header.php';
        ?>
        
        <div class="breadcrumbs">
            <div class="container">
                <a href="<?php echo BASE_PATH; ?>/">Главная</a>
                <span>/</span>
                <a href="<?php echo BASE_PATH; ?>/news.php">Новости</a>
                <span>/</span>
                <?php echo htmlspecialchars($news_item['title']); ?>
            </div>
        </div>
        
        <section class="section">
            <div class="container">
                <div class="news-detail">
                    <?php if ($news_item['image']): ?>
                    <img src="<?php echo BASE_PATH . '/' . $news_item['image']; ?>" 
                         alt="<?php echo htmlspecialchars($news_item['title']); ?>" 
                         class="news-detail-image">
                    <?php endif; ?>
                    
                    <h1 class="news-detail-title"><?php echo htmlspecialchars($news_item['title']); ?></h1>
                    
                    <div class="news-detail-meta">
                        <span>📅 <?php echo formatDate($news_item['published_at']); ?></span>
                        <?php if ($news_item['author_name']): ?>
                        <span style="margin-left: 20px;">✍️ <?php echo htmlspecialchars($news_item['author_name']); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($news_item['announce']): ?>
                    <div style="background: #f5f7fa; padding: 20px; border-radius: 10px; margin-bottom: 30px; font-style: italic; color: #555;">
                        <?php echo htmlspecialchars($news_item['announce']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="news-detail-body">
                        <?php echo nl2br(htmlspecialchars($news_item['body'])); ?>
                    </div>
                    
                    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e0e0e0;">
                        <a href="<?php echo BASE_PATH; ?>/news.php" class="btn btn-outline">← Все новости</a>
                        <a href="<?php echo BASE_PATH; ?>/appointment.php" class="btn btn-primary" style="margin-left: 10px;">Записаться на приём</a>
                    </div>
                </div>
            </div>
        </section>
        
        <?php
        include __DIR__ . '/includes/footer.php';
        exit();
    }
}

// Если нет ID или новость не найдена - показываем список
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 6;
$offset = ($page - 1) * $per_page;

$count_query = "SELECT COUNT(*) FROM news WHERE is_visible = 1";
$total = $conn->query($count_query)->fetchColumn();
$total_pages = ceil($total / $per_page);

$query = "SELECT n.*, u.login as author_name 
          FROM news n 
          LEFT JOIN users u ON n.author_id = u.id 
          WHERE n.is_visible = 1 
          ORDER BY n.published_at DESC 
          LIMIT $per_page OFFSET $offset";
$news = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumbs">
    <div class="container">
        <a href="<?php echo BASE_PATH; ?>/">Главная</a>
        <span>/</span>
        Новости
    </div>
</div>

<section class="section">
    <div class="container">
        <h1 class="section-title">Новости и статьи</h1>
        
        <?php if (count($news) > 0): ?>
        <div class="news-grid">
            <?php foreach ($news as $item): ?>
            <div class="news-card">
                <?php if ($item['image']): ?>
                <img src="<?php echo BASE_PATH . '/' . $item['image']; ?>" 
                     alt="<?php echo htmlspecialchars($item['title']); ?>" 
                     class="news-image">
                <?php else: ?>
                <div style="height: 200px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">
                    📰
                </div>
                <?php endif; ?>
                
                <div class="news-content">
                    <p class="news-date">
                        📅 <?php echo formatDate($item['published_at']); ?>
                        <?php if ($item['author_name']): ?>
                        <span style="margin-left: 15px;">✍️ <?php echo htmlspecialchars($item['author_name']); ?></span>
                        <?php endif; ?>
                    </p>
                    <h3 class="news-title">
                        <a href="<?php echo BASE_PATH; ?>/news.php?id=<?php echo $item['id']; ?>" style="color: #263238; text-decoration: none;">
                            <?php echo htmlspecialchars($item['title']); ?>
                        </a>
                    </h3>
                    <p class="news-announce">
                        <?php echo htmlspecialchars($item['announce']); ?>
                    </p>
                    <a href="<?php echo BASE_PATH; ?>/news.php?id=<?php echo $item['id']; ?>" class="btn btn-outline">Читать далее</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="<?php echo BASE_PATH; ?>/news.php?page=<?php echo $page - 1; ?>">← Предыдущая</a>
            <?php endif; ?>
            
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="<?php echo BASE_PATH; ?>/news.php?page=<?php echo $i; ?>" class="<?php echo $page == $i ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
            <?php endfor; ?>
            
            <?php if ($page < $total_pages): ?>
            <a href="<?php echo BASE_PATH; ?>/news.php?page=<?php echo $page + 1; ?>">Следующая →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php else: ?>
        <div style="text-align: center; padding: 60px 20px;">
            <div style="font-size: 64px; margin-bottom: 20px;">📰</div>
            <h3 style="color: #263238; margin-bottom: 10px;">Новостей пока нет</h3>
            <p style="color: #78909c;">Следите за обновлениями! Мы скоро опубликуем интересные материалы.</p>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>